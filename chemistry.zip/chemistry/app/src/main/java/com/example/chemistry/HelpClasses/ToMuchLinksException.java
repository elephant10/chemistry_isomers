package com.example.chemistry.HelpClasses;

public class ToMuchLinksException extends RuntimeException {
}
