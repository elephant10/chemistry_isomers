package com.example.chemistry.Logic;

import com.example.chemistry.multiset.Multiset;

public class LinkName {
    private Multiset<Elements> presents = new Multiset<>();

    public LinkName() {

    }

    @Override
    public boolean equals(Object ln) {
        LinkName linkName = (LinkName) ln;
        return getPresents().equals(linkName.getPresents());
    }

    LinkName(Multiset<Elements> pr) {
        presents = pr;
    }

    public void add(Elements e, Integer a) {
        presents.add(e, a);
    }

    Multiset<Elements> getPresents() {
        return presents;
    }
}
