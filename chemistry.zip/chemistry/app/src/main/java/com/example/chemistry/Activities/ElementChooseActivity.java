package com.example.chemistry.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.util.ArraySet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.chemistry.Adapter.ChoosedElementAdapter;
import com.example.chemistry.Logic.Elements;
import com.example.chemistry.Logic.Link;
import com.example.chemistry.Logic.LinkName;
import com.example.chemistry.Logic.LinkWriter;
import com.example.chemistry.R;
import com.example.chemistry.HelpClasses.ToMuchLinksException;

import java.util.ArrayList;

import static com.example.chemistry.Logic.Elements.*;

public class ElementChooseActivity extends AppCompatActivity {
    RecyclerView choosedEllements;
    static volatile ArrayList<Link> isomers;
    static Thread workThread;
    public static volatile boolean canRun = true;
    public static volatile boolean isRun = false;
    @Override
    public void onBackPressed() {
        try {
            if(workThread!=null) {
                workThread.interrupt();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            super.onBackPressed();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_element_choose);
        choosedEllements = findViewById(R.id.elementChoosed);
        choosedEllements.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        ChoosedElementAdapter choosedElementAdapter = new ChoosedElementAdapter();
        choosedEllements.setAdapter(choosedElementAdapter);
        final ArraySet<Elements> els = new ArraySet<>();
        els.add(Carbon);
        els.add(Hydrogen);
        els.add(Oxygen);
        els.add(Nitrogen);
        choosedElementAdapter.setItems(els);

        Button mkIs = findViewById(R.id.makeIsomer);
        View.OnClickListener createClickListener = new View.OnClickListener() {
            int bbdzc = 0;

            @Override
            public void onClick(View view) {
                LinkName linkName = new LinkName();
                for (int i = 0; i < choosedEllements.getChildCount(); i++) {
                    String s = ((EditText) (choosedEllements.getChildAt(i).findViewById(R.id.elementNumber))).getText().toString();
                    int n;
                    if (s.equals("")) continue;
                    else {
                        try {
                            n = Integer.parseInt(s);
                        } catch (NumberFormatException e) {
                            Toast.makeText(ElementChooseActivity.this, "будь ласка, введіть додатні числа", Toast.LENGTH_LONG).show();
                            return;
                        }
                    }

                    linkName.add(els.valueAt(i), n);
                }
                try {
                    final Link link0 = new LinkWriter(linkName).create();
                    isomers = new ArrayList<>();
                    workThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Looper.prepare();
                            LinkWriter.makeIsomers(link0, isomers);
                            // Toast.makeText(getApplicationContext(), "усі ізомери згенеровані", Toast.LENGTH_LONG).show();
                        }
                    });
                    workThread.start();
                    // Toast.makeText(ElementChooseActivity.this, "making of isomer started", Toast.LENGTH_SHORT).show();
                    while (isomers.size() == 0) {

                    }
                    Intent i = new Intent(ElementChooseActivity.this, DisplayerActivity.class);
                    startActivity(i);

                } catch (ToMuchLinksException e) {
                    Toast.makeText(ElementChooseActivity.this, "нажаль, така сполука не може існувати", Toast.LENGTH_LONG).show();
                }
            }
        };
        mkIs.setOnClickListener(createClickListener);
        Button train = findViewById(R.id.train);
        View.OnClickListener trainClickListener = new View.OnClickListener() {
            int sffa = 0;

            @Override
            public void onClick(View view) {
                LinkName linkName = new LinkName();
                for (int i = 0; i < choosedEllements.getChildCount(); i++) {
                    String s = ((EditText) (choosedEllements.getChildAt(i).findViewById(R.id.elementNumber))).getText().toString();
                    int n;
                    if (s.equals("")) continue;
                    else {
                        try {
                            n = Integer.parseInt(s);
                        } catch (NumberFormatException e) {
                            Toast.makeText(ElementChooseActivity.this, "будь ласка, введіть додатні числа", Toast.LENGTH_LONG).show();
                            return;
                        }
                    }

                    linkName.add(els.valueAt(i), n);
                }
                try {
                    final Link link0 = new LinkWriter(linkName).create();
                    isomers = new ArrayList<>();
                    workThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Looper.prepare();
                            LinkWriter.makeIsomers(link0, isomers);
                            //Toast.makeText(getApplicationContext(), "all isomers created", Toast.LENGTH_LONG).show();
                        }
                    });
                    workThread.start();

                    // Toast.makeText(ElementChooseActivity.this, "making of isomer started", Toast.LENGTH_SHORT).show();
                    while (isomers.size() == 0) {

                    }
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Intent i = new Intent(ElementChooseActivity.this, TrainActivity.class);
                            startActivity(i);
                        }
                    }).start();
                } catch (ToMuchLinksException e) {
                    Toast.makeText(ElementChooseActivity.this, "нажаль, така сполука не може існувати", Toast.LENGTH_LONG).show();
                }
            }
        };
        train.setOnClickListener(trainClickListener);
    }
}