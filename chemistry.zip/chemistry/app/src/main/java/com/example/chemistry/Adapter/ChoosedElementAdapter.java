package com.example.chemistry.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chemistry.Logic.Elements;
import com.example.chemistry.R;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ChoosedElementAdapter extends RecyclerView.Adapter<ChoosedElementAdapter.ElementViewHolder> {
    List<Elements> elementList = new ArrayList<>();

    @Override
    public ElementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.elementlayout, parent, false);
        return new ElementViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ElementViewHolder holder, int position) {
        holder.bind(elementList.get(position));
    }

    @Override
    public int getItemCount() {
        return elementList.size();
    }


    public void setItems(Collection<Elements> elements) {
        elementList.addAll(elements);
        notifyDataSetChanged();
    }

    public void clearItems() {
        elementList.clear();
        notifyDataSetChanged();
    }

    class ElementViewHolder extends RecyclerView.ViewHolder {
        TextView elementName;
        EditText elementNumber;

        public void bind(Elements element) {
            elementName.setText(element.toString());
        }


        public ElementViewHolder(View itemView) {
            super(itemView);
            elementName = itemView.findViewById(R.id.elementName);
            elementNumber = itemView.findViewById(R.id.elementNumber);
        }


    }
}