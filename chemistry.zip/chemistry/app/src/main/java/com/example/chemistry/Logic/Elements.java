package com.example.chemistry.Logic;

public enum Elements {
    Carbon(4,"C"),
    Nitrogen(3,"N"),
    Oxygen(2,"O"),
    Hydrogen(1,"H");

    private final int volentnost;
    private final String shortName;


    Elements(int a, String shortName) {
        volentnost = a;
        this.shortName = shortName;
    }

    public int getVolentnost() {
        return volentnost;
    }

    public  String shortName(){
        return shortName;
    }
}
