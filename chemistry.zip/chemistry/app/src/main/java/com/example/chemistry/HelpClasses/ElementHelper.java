package com.example.chemistry.HelpClasses;

import android.widget.TextView;
import com.example.chemistry.Logic.Elements;

public class ElementHelper {

    public ElementHelper(Elements element, TextView textView) {
        this.element = element;
        this.linkAtoms = new ElementHelper[element.getVolentnost()];
        this.textView = textView;
        imgs = new ImageHelper[element.getVolentnost()];
    }

    private TextView textView;
    private Elements element;
    private ElementHelper[] linkAtoms;
    private ImageHelper[] imgs;

    public ElementHelper[] getLinkAtoms() {
        return linkAtoms;
    }

    public Elements getElement() {
        return element;
    }

    public TextView getTextView() {
        return textView;
    }

    public ImageHelper[] getImgs() {
        return imgs;
    }
}