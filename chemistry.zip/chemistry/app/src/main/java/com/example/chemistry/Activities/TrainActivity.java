package com.example.chemistry.Activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.util.Pair;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.chemistry.HelpClasses.ElementHelper;
import com.example.chemistry.HelpClasses.ImageHelper;
import com.example.chemistry.Logic.Elements;

import com.example.chemistry.Logic.Link;
import com.example.chemistry.R;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;

public class TrainActivity extends AppCompatActivity {
    @Override
    public void onBackPressed() {
        try {
            ElementChooseActivity.workThread.interrupt();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            super.onBackPressed();
        }
    }

    double foundAngle(float centerX, float centerY, float pointX, float pointY) {
        // ищем угол с помощью векторов
        pointX -= centerX;
        pointY -= centerY;
        float helpPointX = 1;
        float helpPointY = 0;
        float distance = (float) Math.sqrt(Math.pow(pointX, 2) + Math.pow(pointY, 2));
        float vextorMultiply = pointX * helpPointX + pointY * helpPointY;
        double cosynus = vextorMultiply / distance;
        if (pointY < 0) return 2 * Math.PI - Math.acos(cosynus);
        else return Math.acos(cosynus);
    }

    ImageHelper createImageViewLink(ElementHelper el1, ElementHelper el2) {
        TextView textView1 = elements.get(elements.indexOf(el1)).getTextView();
        TextView textView2 = elements.get(elements.indexOf(el2)).getTextView();
        // ElementHelper ind = elements.indexOf(el1);
        int num = 0;
        for (ElementHelper a : el2.getLinkAtoms()) {
            if (Objects.equals(a, el1)) num++;
        }
        ImageView imageView = new ImageView(this);
        ConstraintLayout.LayoutParams cs = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT,
                ConstraintLayout.LayoutParams.WRAP_CONTENT);
        constraintLayout.addView(imageView, cs);
        int dist = (int) Math.sqrt(Math.pow(textView1.getX() + textView1.getPivotX() - textView2.getX() - textView2.getPivotX(), 2)
                + Math.pow(textView1.getY() + textView1.getPivotY() - textView2.getY() - textView2.getPivotY(), 2));
        Bitmap b = Bitmap.createBitmap(dist, 5, Bitmap.Config.ALPHA_8);
        Canvas c = new Canvas(b);
        c.drawColor(Color.BLACK);
        imageView.setImageBitmap(b);
        imageView.setY((float) (textView2.getY() + textView2.getPivotY() + 9 * (num) * Math.pow(-1, num + 1)));
        imageView.setX(textView2.getX() + textView2.getPivotX());
        double ang = foundAngle(textView2.getX() + textView2.getPivotX(), textView2.getY() + textView2.getPivotY(),
                textView1.getX() + textView1.getPivotX(), textView1.getY() + textView1.getPivotY());
        imageView.setPivotX(0);
        imageView.setPivotY(0);
        imageView.setRotation((float) (ang / Math.PI * 180));
        return new ImageHelper(imageView, el1, el2);
    }

    ElementHelper helperByView(TextView view) {
        ElementHelper a = null;
        for (int i = 0; i < elements.size(); i++) {
            if (elements.get(i).getTextView() == view) a = elements.get(i);
        }
        return a;
    }

    ArrayList<Link> checkedByUser = new ArrayList<>();
    ArrayList<ElementHelper> elements = new ArrayList<>();


    volatile boolean resume = true;
    ConstraintLayout constraintLayout;
    ImageView trashBox;
    ImageView check;
    ImageView eye;
    TextView carbonText;
    TextView oxygenText;
    TextView nitrogenText;
    TextView hydrogenText;

    View.OnTouchListener otl = new View.OnTouchListener() {
        private final static int START_DRAGGING = 0;
        private final static int STOP_DRAGGING = 1;
        private int status;
        int flag = 0;
        float xAxis = 0f;
        float yAxis = 0f;
        float lastXAxis = 0f;
        float lastYAxis = 0f;

        @Override
        public boolean onTouch(View v, MotionEvent me) {
            TextView textView = (TextView) v;
            if (me.getAction() == MotionEvent.ACTION_DOWN) {
                status = START_DRAGGING;
                final float x = me.getX();
                final float y = me.getY();
                lastXAxis = x;
                lastYAxis = y;
            } else if (me.getAction() == MotionEvent.ACTION_UP) {
                status = STOP_DRAGGING;
                flag = 0;
                float viewX = textView.getX() + (textView.getMeasuredWidth() / 2);
                if (textView.getY() < trashBox.getY() + trashBox.getMeasuredHeight() &&
                        viewX > trashBox.getX() && viewX < trashBox.getX() + trashBox.getMeasuredWidth()) {
                    ElementHelper index = helperByView(textView);
                    for (int i = 0; i < elements.size(); i++) {
                        for (int j = 0; j < elements.get(i).getLinkAtoms().length; j++) {
                            if (elements.get(i).getLinkAtoms()[j] != null) {
                                if (elements.get(i).getLinkAtoms()[j] == index) {
                                    elements.get(i).getLinkAtoms()[j] = null;
                                    elements.get(i).getImgs()[j].getImage().setImageDrawable(null);
                                    elements.get(i).getImgs()[j].getImage().setVisibility(View.GONE);
                                    elements.get(i).getImgs()[j] = null;
                                    continue;
                                }
                            }
                        }
                    }
                    index.getTextView().setVisibility(View.GONE);
                    elements.remove(index);
                }

            } else if (me.getAction() == MotionEvent.ACTION_MOVE) {
                if (status == START_DRAGGING) {
                    for (ElementHelper h : elements) {
                        h.getTextView().setOnLongClickListener(clk);
                        h.getTextView().setTextColor(Color.BLACK);
                    }
                    oxygenText.setVisibility(View.VISIBLE);
                    nitrogenText.setVisibility(View.VISIBLE);
                    hydrogenText.setVisibility(View.VISIBLE);
                    carbonText.setVisibility(View.VISIBLE);
                    flag = 1;
                    final float x = me.getX();
                    final float y = me.getY();
                    final float dx = x - lastXAxis;
                    final float dy = y - lastYAxis;
                    xAxis += dx;
                    yAxis += dy;
                    v.setX((int) xAxis);
                    v.setY((int) yAxis);
                    {
                        for (int i = 0; i < helperByView(textView).getLinkAtoms().length; i++) {

                            if (helperByView(textView).getLinkAtoms()[i] == null)
                                continue;
                            TextView t = helperByView(textView).getLinkAtoms()[i].getTextView();
                            // TextView t = elements.get(elements.get(elements.indexOf(textView)).linkAtoms[i]);
                            ImageView imageView = helperByView(textView).getImgs()[i].getImage();

                            // ImageView imageView = imageViews.get(elements.get(helperByView(textView)).linlkImage[i]);
                            int dist = (int) Math.sqrt(Math.pow(textView.getX() + textView.getPivotX() - t.getX() - t.getPivotX(), 2)
                                    + Math.pow(textView.getY() - textView.getPivotY() - t.getY() + t.getPivotY(), 2));
                            Bitmap b = Bitmap.createBitmap(dist, 5, Bitmap.Config.ALPHA_8);
                            Canvas c = new Canvas(b);
                            c.drawColor(Color.BLACK);
                            imageView.setImageBitmap(b);
                            ElementHelper ind = helperByView(t);
                            int num = 0;
                            for (int j = 0; j <= i; j++) {
                                if (Objects.equals(helperByView(textView).getLinkAtoms()[j], ind))
                                    num++;
                            }
                            if (helperByView(textView).getImgs()[i].getStart() == helperByView(t)) {
                                imageView.setY((float) (t.getY() + t.getPivotY() + 9 * (num) * Math.pow(-1, num + 1)));
                                imageView.setX(t.getX() + t.getPivotX());
                                double ang = foundAngle(t.getX() + t.getPivotX(), t.getY() + t.getPivotY(),
                                        textView.getX() + textView.getPivotX(), textView.getY() + textView.getPivotY());
                                // System.out.println(imageView.getPivotX() + " "+ imageView.getPivotY());
                                imageView.setRotation((float) (ang / Math.PI * 180));
                                imageView.invalidate();
                            }else{
                                imageView.setY((float) (textView.getY() + textView.getPivotY() + 9 * (num) * Math.pow(-1, num + 1)));
                                imageView.setX(textView.getX() + textView.getPivotX());
                                double ang = foundAngle(textView.getX() + textView.getPivotX(), textView.getY() + textView.getPivotY(),
                                        t.getX() + t.getPivotX(), t.getY() + t.getPivotY());
                                // System.out.println(imageView.getPivotX() + " "+ imageView.getPivotY());
                                imageView.setRotation((float) (ang / Math.PI * 180));
                                imageView.invalidate();
                            }
                        }
                    }
                    float viewX = textView.getX() + (textView.getMeasuredWidth() / 2);
                    if (textView.getY() < trashBox.getY() + trashBox.getMeasuredHeight() &&
                            viewX > trashBox.getX() && viewX < trashBox.getX() + trashBox.getMeasuredWidth()) {
                        textView.setBackgroundColor(Color.RED);
                    } else {
                        textView.setBackground(null);
                    }

                    v.invalidate();
                }
            }
            return false;
        }
    };
    View.OnLongClickListener clk = new View.OnLongClickListener() {
        int a = 0;

        @Override
        public boolean onLongClick(View view) {
            trashBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
            carbonText.setVisibility(View.GONE);
            oxygenText.setVisibility(View.GONE);
            nitrogenText.setVisibility(View.GONE);
            hydrogenText.setVisibility(View.GONE);
            final TextView textView = (TextView) view;
            textView.setTextColor(Color.GREEN);
            // System.out.println("long");
            final ElementHelper index = helperByView(textView);
            int freeInd = -1;
            for (int i = 0; i < index.getLinkAtoms().length; i++) {
                if (index.getLinkAtoms()[i] == null) {
                    freeInd = i;
                    break;
                }
            }
            if (freeInd != -1) {
                for (int i = 0; i < elements.size(); i++) {
                    if (elements.get(i) != index) {
                        int freeInd1 = -1;
                        for (int j = 0; j < elements.get(i).getLinkAtoms().length; j++) {
                            if (elements.get(i).getLinkAtoms()[j] == null) {
                                freeInd1 = j;
                                break;
                            }
                        }
                        if (freeInd1 != -1) {
                            final int finalI = i;
                            final int finalFreeInd = freeInd;
                            final int finalFreeInd1 = freeInd1;
                            elements.get(i).getTextView().setOnLongClickListener(new View.OnLongClickListener() {
                                @Override
                                public boolean onLongClick(View view) {
                                    //forNewClickListener = this;
                                    index.getLinkAtoms()[finalFreeInd] = elements.get(finalI);
                                    elements.get(finalI).getLinkAtoms()[finalFreeInd1] = index;
                                    ImageHelper imageView = createImageViewLink(index, elements.get(finalI));
                                    index.getImgs()[finalFreeInd] = imageView;
                                    elements.get(finalI).getImgs()[finalFreeInd1] = imageView;
                                    carbonText.setVisibility(View.VISIBLE);
                                    oxygenText.setVisibility(View.VISIBLE);
                                    nitrogenText.setVisibility(View.VISIBLE);
                                    hydrogenText.setVisibility(View.VISIBLE);
                                    trashBox.setOnClickListener(trashListener);
                                    for (ElementHelper t : elements) {
                                        t.getTextView().setTextColor(Color.BLACK);
                                        t.getTextView().setOnLongClickListener(clk);
                                    }
                                    return true;
                                }
                            });
                        } else {
                            elements.get(i).getTextView().setTextColor(Color.BLUE);
                            elements.get(i).getTextView().setOnLongClickListener(new View.OnLongClickListener() {
                                @Override
                                public boolean onLongClick(View view) {
                                    return true;
                                }
                            });
                        }
                    } else {
                        textView.setOnLongClickListener(new View.OnLongClickListener() {

                            @Override
                            public boolean onLongClick(View view) {
                                carbonText.setVisibility(View.VISIBLE);
                                oxygenText.setVisibility(View.VISIBLE);
                                nitrogenText.setVisibility(View.VISIBLE);
                                hydrogenText.setVisibility(View.VISIBLE);
                                trashBox.setOnClickListener(trashListener);
                                for (ElementHelper t : elements) {
                                    t.getTextView().setTextColor(Color.BLACK);
                                    t.getTextView().setOnLongClickListener(clk);
                                }
                                return true;
                            }
                        });
                    }
                }
            } else {
                carbonText.setVisibility(View.VISIBLE);
                oxygenText.setVisibility(View.VISIBLE);
                nitrogenText.setVisibility(View.VISIBLE);
                hydrogenText.setVisibility(View.VISIBLE);
                trashBox.setOnClickListener(trashListener);
                for (ElementHelper t : elements) {
                    t.getTextView().setTextColor(Color.BLACK);
                    t.getTextView().setOnLongClickListener(clk);
                }
            }
            return true;
        }
    };
    View.OnClickListener trashListener = new View.OnClickListener() {
        int fehw;

        @Override
        public void onClick(View v) {
            resume = true;
            for (ElementHelper h : elements) {
                h.getTextView().setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        return false;
                    }
                });
                for (final ImageHelper imageHelper : h.getImgs()) {
                    if (imageHelper == null) continue;
                    final Animation alf = new AlphaAnimation(1f, 0.2f);
                    alf.setDuration(300);
                    final Animation alf1 = new AlphaAnimation(0.2f, 1.0f);
                    alf1.setDuration(300);
                    final ImageView iv = imageHelper.getImage();
                    alf.setAnimationListener(new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(Animation animation) {

                        }

                        @Override
                        public void onAnimationEnd(Animation animation) {
                            if (resume) iv.startAnimation(alf1);
                        }

                        @Override
                        public void onAnimationRepeat(Animation animation) {

                        }
                    });
                    alf1.setAnimationListener(new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(Animation animation) {

                        }

                        @Override
                        public void onAnimationEnd(Animation animation) {
                            if (resume) iv.startAnimation(alf);
                        }

                        @Override
                        public void onAnimationRepeat(Animation animation) {

                        }
                    });
                    iv.startAnimation(alf);
                    iv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            for (int i = 0; i < imageHelper.getStart().getImgs().length; i++) {
                                if (imageHelper.getStart().getImgs()[i] == null) continue;
                                if (imageHelper.getStart().getImgs()[i].getImage() == iv) {
                                    imageHelper.getStart().getLinkAtoms()[i] = null;
                                    imageHelper.getStart().getImgs()[i] = null;
                                    break;
                                }
                            }
                            for (int i = 0; i < imageHelper.getFinish().getImgs().length; i++) {
                                if (imageHelper.getFinish().getImgs()[i] == null) continue;
                                if (imageHelper.getFinish().getImgs()[i].getImage() == iv) {
                                    imageHelper.getFinish().getLinkAtoms()[i] = null;
                                    imageHelper.getFinish().getImgs()[i] = null;
                                    break;
                                }
                            }
                            iv.setVisibility(View.GONE);
                            iv.setImageDrawable(null);
                        }
                    });
                }
            }
            trashBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    resume = false;
                    for (ElementHelper h : elements) {
                        h.getTextView().setOnLongClickListener(clk);
                        for (final ImageHelper imageHelper : h.getImgs()) {
                            if (imageHelper == null) continue;
                            imageHelper.getImage().setOnLongClickListener(new View.OnLongClickListener() {
                                @Override
                                public boolean onLongClick(View v) {
                                    return false;
                                }
                            });
                        }
                    }
                    trashBox.setOnClickListener(trashListener);
                }
            });
        }
    };


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_train);
        constraintLayout = findViewById(R.id.constraintLayout);
        carbonText = findViewById(R.id.carbonText);
        oxygenText = findViewById(R.id.oxygenText);
        nitrogenText = findViewById(R.id.nitrogenText);
        hydrogenText = findViewById(R.id.hydrogenText);
        trashBox = findViewById(R.id.trashBox);
        carbonText.setTextSize(25);
        oxygenText.setTextSize(25);
        nitrogenText.setTextSize(25);
        hydrogenText.setTextSize(25);
        trashBox.measure(0, 0);
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        final int width = size.x;
        final int height = size.y;
        addingClickListeners:
        {
            carbonText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final TextView textView = new TextView(TrainActivity.this);
                    textView.setTextSize(40);
                    textView.setText("C");
                    textView.setX(width >> 1);
                    textView.setY(height >> 1);
                    textView.measure(0, 0);
                    textView.setPivotX(textView.getMeasuredWidth() / 2);
                    textView.setPivotY(textView.getMeasuredHeight() / 2);
                    ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT,
                            ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    constraintLayout.addView(textView, lp);
                    elements.add(new ElementHelper(Elements.Carbon, textView));
                    textView.setOnLongClickListener(clk);
                    textView.setOnTouchListener(otl);
                }
            });
            oxygenText.setOnClickListener(new View.OnClickListener() {
                int ufehsf;

                @Override
                public void onClick(View view) {
                    final TextView textView = new TextView(TrainActivity.this);
                    textView.setTextSize(40);
                    textView.setText("O");
                    textView.setX(width / 2);
                    textView.setY(height / 2);
                    textView.measure(0, 0);
                    textView.setPivotX(textView.getMeasuredWidth() / 2);
                    textView.setPivotY(textView.getMeasuredHeight() / 2);
                    ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT,
                            ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    constraintLayout.addView(textView, lp);
                    //  elements.add(textView);
                    elements.add(new ElementHelper(Elements.Oxygen, textView));
                    textView.setOnLongClickListener(clk);
                    textView.setOnTouchListener(otl);

                }
            });
            nitrogenText.setOnClickListener(new View.OnClickListener() {
                int ifseuihdisc;

                @Override
                public void onClick(View view) {
                    final TextView textView = new TextView(TrainActivity.this);
                    textView.setTextSize(40);
                    textView.setText("N");
                    textView.setX(width / 2);
                    textView.setY(height / 2);
                    textView.measure(0, 0);
                    textView.setPivotX(textView.getMeasuredWidth() / 2);
                    textView.setPivotY(textView.getMeasuredHeight() / 2);
                    ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT,
                            ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    constraintLayout.addView(textView, lp);
                    elements.add(new ElementHelper(Elements.Nitrogen, textView));
                    textView.setOnLongClickListener(clk);
                    textView.setOnTouchListener(otl);
                }
            });
            hydrogenText.setOnClickListener(new View.OnClickListener() {
                int dskfhshnis;

                @Override
                public void onClick(View view) {
                    final TextView textView = new TextView(TrainActivity.this);
                    textView.setTextSize(40);
                    textView.setText("H");
                    textView.setX(width / 2);
                    textView.setY(height / 2);
                    textView.measure(0, 0);
                    textView.setPivotX(textView.getMeasuredWidth() / 2);
                    textView.setPivotY(textView.getMeasuredHeight() / 2);
                    ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT,
                            ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    constraintLayout.addView(textView, lp);
                    elements.add(new ElementHelper(Elements.Hydrogen, textView));
                    textView.setOnLongClickListener(clk);
                    textView.setOnTouchListener(otl);
                }
            });
        }
        check = findViewById(R.id.check);
        eye = findViewById(R.id.eye);
        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(TrainActivity.this, DisplayerActivity.class);
                startActivity(i);
            }
        });
        check.setOnClickListener(new View.OnClickListener() {
            int uyfdysgd;

            @Override
            public void onClick(View view) {
                if (elements.size() == 0) return;
                elements.sort(new Comparator<ElementHelper>() {
                    @Override
                    public int compare(ElementHelper elementHelper, ElementHelper t1) {
                        return elementHelper.getElement().compareTo(t1.getElement());
                    }
                });
                boolean wrong = false;
                for (ElementHelper h : elements) {
                    for (ElementHelper a : h.getLinkAtoms()) {
                        if (a == null) {
                            wrong = true;
                            final TextView t = h.getTextView();
                            Toast.makeText(TrainActivity.this, "у деяких атомів є вільні місця, чого не має бути", Toast.LENGTH_SHORT).show();
                            Animation t1 = new TranslateAnimation(0, 0, 0, 10);
                            t1.setDuration(100);
                            final Animation t2 = new TranslateAnimation(0, 0, 10, -10);
                            t2.setDuration(100);
                            final Animation t3 = new TranslateAnimation(0, 0, -10, 0);
                            t3.setDuration(100);
                            t1.setAnimationListener(new Animation.AnimationListener() {
                                @Override
                                public void onAnimationStart(Animation animation) {

                                }

                                @Override
                                public void onAnimationEnd(Animation animation) {
                                    t.startAnimation(t2);
                                }

                                @Override
                                public void onAnimationRepeat(Animation animation) {

                                }
                            });
                            t2.setAnimationListener(new Animation.AnimationListener() {
                                @Override
                                public void onAnimationStart(Animation animation) {

                                }

                                @Override
                                public void onAnimationEnd(Animation animation) {
                                    t.startAnimation(t3);
                                }

                                @Override
                                public void onAnimationRepeat(Animation animation) {

                                }
                            });
                            t.startAnimation(t1);
                        }
                    }
                }
                if (wrong) return;
                Link link = new Link();
                ArrayList<Pair<Elements, Integer[]>> isomer = link.atomsInLink;
                for (int i = 0; i < elements.size(); i++) {
                    Integer[] conns = new Integer[elements.get(i).getElement().getVolentnost()];
                    for (int j = 0; j < conns.length; j++) {
                        conns[j] = elements.indexOf(elements.get(i).getLinkAtoms()[j]);
                    }
                    isomer.add(new Pair<>(elements.get(i).getElement(), conns));

                }
                if (!link.isUnited()) {
                    Toast.makeText(TrainActivity.this, "Усі атоми мають бути з'єднаними у єдину мережу", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!link.getLinkName().equals(ElementChooseActivity.isomers.get(0).getLinkName())) {
                    Toast.makeText(TrainActivity.this, "не співпадають атоми у заданій сполуці та намальованій", Toast.LENGTH_SHORT).show();
                    return;
                }
                for (Integer a:link.findCicclers()){
                    elements.get(a).getTextView().setTextColor(Color.YELLOW);
                }
                for (Link l : checkedByUser) {
                    if (link.equals(l)) {
                        Toast.makeText(TrainActivity.this, "ви вже створювали цей ізомер", Toast.LENGTH_SHORT).show();
                        if ((!ElementChooseActivity.workThread.isAlive()) && ElementChooseActivity.isomers.size() == checkedByUser.size()) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(TrainActivity.this);
                            builder.setTitle("Ви створили усі ізомери заданої сполуки")
                                    .setMessage("ви молодець")
                                    // .setIcon(R.drawable.ic_android_cat)
                                    .setCancelable(true)
                                    .setNegativeButton("ОК",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    dialog.cancel();
                                                }
                                            });
                            AlertDialog alert = builder.create();
                            alert.show();
                        }

                        return;
                    }
                }
                for (Integer a:link.findCicclers()){
                    elements.get(a).getTextView().setTextColor(Color.YELLOW);
                }
                ElementChooseActivity.canRun = false;
                while (ElementChooseActivity.isRun) {

                }
                for (Link l : ElementChooseActivity.isomers) {
                    if (link.equals(l)) {
                        Toast.makeText(TrainActivity.this, "правильний ізомер", Toast.LENGTH_SHORT).show();
                        checkedByUser.add(link);
                        ElementChooseActivity.canRun = true;
                        if ((!ElementChooseActivity.workThread.isAlive()) && ElementChooseActivity.isomers.size() == checkedByUser.size()) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(TrainActivity.this);
                            builder.setTitle("Ви створили усі ізомери заданої сполуки")
                                    .setMessage("ви молодець")
                                    // .setIcon(R.drawable.ic_android_cat)
                                    .setCancelable(true)
                                    .setNegativeButton("ОК",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    dialog.cancel();
                                                }
                                            });
                            AlertDialog alert = builder.create();
                            alert.show();
                        }
                        return;
                    }

                }
                ElementChooseActivity.isomers.add(link);
                checkedByUser.add(link);
                Toast.makeText(TrainActivity.this, "правильний ізомер", Toast.LENGTH_SHORT).show();
                ElementChooseActivity.canRun = true;
                for (Integer a:link.findCicclers()){
                    elements.get(a).getTextView().setTextColor(Color.YELLOW);
                }
            }
        });
        trashBox.setOnClickListener(trashListener);

    }
}