package com.example.chemistry.Logic;

import android.util.Pair;

import com.example.chemistry.HelpClasses.ToMuchLinksException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class LinkWriter {

    ArrayList<Elements> elements = new ArrayList<>();
    boolean possible;
    int not1volent = 0;
    int excess = 0;

    public LinkWriter(LinkName linkName) {
        for (Elements e : linkName.getPresents().elementSet()) {
            for (int j = 0; j < linkName.getPresents().count(e); j++) {
                elements.add(e);
            }
        }
        Collections.sort(elements);
        int n1 = 0;

        for (Elements e : elements) {
            if (e.getVolentnost() == 1) {
                n1++;
            } else {
                not1volent++;
                excess += e.getVolentnost();
            }
        }
        excess -= 2 * (not1volent - 1);
        possible = excess >= n1 & (excess -= n1) % 2 == 0;
        if (not1volent == 1) {
            possible = elements.get(0).getVolentnost() == n1;
        }
        if (linkName.getPresents().size() < 2) possible = false;
        if (!possible) throw new ToMuchLinksException();
    }

    public Link create() throws ToMuchLinksException {
        System.out.println(possible);
        if (!possible) {
            throw new ToMuchLinksException();
        }
        excess /= 2;
        Link link0 = new Link(elements.remove(0));
        if (not1volent > 1) {
            System.out.println(excess + " " + not1volent);
            int averageVol = excess / ((not1volent - 1)) + 1;
            int excessForElements = excess % ((not1volent - 1));
            System.out.println(averageVol + " " + excessForElements);
            //    ArrayList<Elements> currentElements = elements;


            while (!elements.isEmpty() && elements.get(0).getVolentnost() != 1) {
                int f = link0.add(elements.remove(0), averageVol);
                excessForElements += 2 * f;
            }
            for (int i = 0; i < link0.atomsInLink.size(); i++) {
                if (excessForElements == 0) break;
                if (link0.hasFreeEl(i)) {
                    for (int j = i + 1; j < link0.atomsInLink.size(); j++) {
                        if (link0.hasFreeEl(j)) {
                            int a = Integer.min(excessForElements, Integer.min(link0.freeEls(i), link0.freeEls(j)));
                            if (a > 0) {
                                link0.setFreeEl(i, j, a);
                                link0.setFreeEl(j, i, a);
                                excessForElements -= a;
                            }
                         //   break;
                        }
                    }
                }
            }
            for (int i = link0.atomsInLink.size() - 1; i > 0; i--) {
                if (excessForElements > 0) {
                    if (!link0.hasFreeEl(0)) break;
                    for (int j = 0; j < link0.atomsInLink.get(i).second.length; j++) {
                        if (link0.atomsInLink.get(i).second[j] == i - 1) {
                            link0.atomsInLink.get(i).second[j] = null;
                            break;
                        }
                    }
                    for (int j = 0; j < link0.atomsInLink.get(i - 1).second.length; j++) {
                        if (link0.atomsInLink.get(i - 1).second[j] == i) {
                            link0.atomsInLink.get(i - 1).second[j] = null;
                            break;
                        }
                    }
                    excessForElements -= 1;
                    link0.setFreeEl(0, i);
                    link0.setFreeEl(i, 0);
                    //    if (excessForElements > 0) {

                    link0.setFreeEl(0, i - 1);
                    link0.setFreeEl(i - 1, 0);
                    excessForElements -= 1;
                    //  }
                } else break;
            }
            for (int i = 0; i < link0.atomsInLink.size(); i++) {
                if (excessForElements > 0) {
                    if (!link0.hasFreeEl(link0.atomsInLink.size() - 1)) break;
                    for (int j = 0; j < link0.atomsInLink.get(i).second.length; j++) {
                        if (link0.atomsInLink.get(i).second[j] == i + 1) {
                            link0.atomsInLink.get(i).second[j] = null;
                            break;
                        }
                    }
                    for (int j = 0; j < link0.atomsInLink.get(i + 1).second.length; j++) {
                        if (link0.atomsInLink.get(i + 1).second[j] == i) {
                            link0.atomsInLink.get(i + 1).second[j] = null;
                            break;
                        }
                    }
                    excessForElements -= 1;
                    link0.setFreeEl(link0.atomsInLink.size() - 1, i);
                    link0.setFreeEl(i, link0.atomsInLink.size() - 1);
                    //    if (excessForElements > 0) {

                    link0.setFreeEl(link0.atomsInLink.size() - 1, i + 1);
                    link0.setFreeEl(i + 1, link0.atomsInLink.size() - 1);
                    excessForElements -= 1;
                    //  }
                } else break;
            }
        }
        for (Elements e : elements) {
            link0.add(e);
        }

        // // System.out.println(elements);
        System.out.println(link0);
        return link0;
    }

    public static void makeIsomers(Link link, ArrayList<Link> isomers) {
        //ArrayList<Link> isomers = new ArrayList<>();
        isomers.add(link);


        for (int u = 0; u < isomers.size(); u++) {  // текущий изомер
            Link currentIsomer = isomers.get(u);
            //boolean foolyloop = currentIsomer.isFoolLoop();
            HashSet<Integer> ciclers = currentIsomer.findCicclers();
            //System.out.println(ciclers);
            iso:
            for (int y = 0; y < currentIsomer.atomsInLink.size(); y++) {  //текущий элемент
                Pair<Elements, Integer[]> currentElement = currentIsomer.atomsInLink.get(y);

                if (currentElement.first.getVolentnost() != 1) {
                    ArrayList<Integer> connectedToThis = new ArrayList<>(); //элементы в соединении
                    ArrayList<Integer> connectedToThis1 = new ArrayList<>(); // номера связей этих элементов с текущим
                    ArrayList<Integer> doubleLinkList = new ArrayList<>();
                    ArrayList<Integer> doubleLinkList1 = new ArrayList<>();
                    boolean doubleLink = false;
                    for (int i = 0; i < currentElement.second.length; i++) {
                        int a = currentElement.second[i];
                        if (currentIsomer.atomsInLink.get(a).first.getVolentnost() != 1) {
                            if (!connectedToThis.contains(a)) {
                                connectedToThis.add(a);
                                connectedToThis1.add(i);
                            } else {
                                doubleLink = true;
                                if (!doubleLinkList.contains(a)) {
                                    doubleLinkList.add(a);
                                    doubleLinkList1.add(i);
                                }
                            }
                        }
                    }
                    if (!doubleLink && connectedToThis.size() != 1 && !ciclers.contains(y)) continue;
                    for (int i = 0; i < currentIsomer.atomsInLink.size(); i++) {  // перебираю остальные атомы для создания изомеров
                        if (currentIsomer.atomsInLink.get(i).first.getVolentnost() == 1) {
                            continue iso;
                        }
                        if (currentIsomer.atomsInLink.get(i) == currentElement /*|| connectedToThis.contains(i)*/) {
                            // // // System.out.println("ne proshlo");
                            continue;
                        }
                        ArrayList<Integer> firstConnections;

                        if (connectedToThis.size() == 1 || ciclers.contains(y)) {
                            firstConnections = connectedToThis1;
                        } else {
                            firstConnections = doubleLinkList1;
                        }

                        for (int l : firstConnections/*.size(); l++*//*firstConnections*/) {  // перебираю, какие соединения первого атома можно менять
                            loop:
                            // // System.out.println("all \n" + isomers);
                            for (int j = 0; j < currentIsomer.atomsInLink.get(i).second.length; j++) {   // перебираю, с чем соединен новый атом
                                /* if (!currentIsomer.atomsInLink.isEmpty()*//* && currentIsomer.atomsInLink.get(currentIsomer.atomsInLink.get(i).second[j]).first.getVolentnost() != 1*//*) {
                                    continue;
                                }*/
                                Link newIsomer = currentIsomer.clone();
                                // System.out.println("before +\n" + newIsomer);
                                try {
                                    // System.out.println("y = " + y + " l=" + l + " i=" + i + " " + "j=" + j);
                                    newIsomer.swap(y, l, i, j);
                                } catch (ToMuchLinksException e) {
                                    continue;
                                }
                                // System.out.println("after \n" + newIsomer);
                                if (!newIsomer.isUnited()) {
                                    // System.out.println("Not United \n");
                                    continue;
                                }
                                // System.out.println("all \n" + isomers);
                                for (Link presentIsomer : isomers) {
                                    if (newIsomer.equals(presentIsomer)) {
                                        // System.out.println("equals");
                                        continue loop;
                                    }
                                }

                                isomers.add(newIsomer);
                            }
                        }


                    }

                }/* else {
                    loop:
                    for (int i = y + 1; i < currentIsomer.atomsInLink.size(); i++) {
                        if (currentElement.getKey().equals(currentIsomer.atomsInLink.get(i).getKey())) continue;
                        else {
                            Link newIsomer = currentIsomer.clone();
                            try {
                                newIsomer.swap(y, 0, i, 0);
                            } catch (ToMuchLinksException t) {
                                continue;
                            }

                            for (Link presentIsomer : isomers) {
                                if (newIsomer.equals(presentIsomer)) {
                                    // System.out.println("equals");
                                    continue loop;
                                }
                            }
                            //if(newIsomer.isUnited())
                            isomers.add(newIsomer);
                        }
                    }
                }*/
            }
        }
    }


}
