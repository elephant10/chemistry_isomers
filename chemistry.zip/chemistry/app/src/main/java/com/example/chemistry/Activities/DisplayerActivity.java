package com.example.chemistry.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chemistry.HelpClasses.ElementHelper;
import com.example.chemistry.HelpClasses.ImageHelper;
import com.example.chemistry.Logic.Elements;
import com.example.chemistry.Logic.Link;
import com.example.chemistry.R;

import java.util.ArrayList;

public class DisplayerActivity extends AppCompatActivity {
    volatile int n = 0;
    ImageButton next, prtvious;
    ArrayList<Link> isos;
    TextView number;
    Button redraw;
    volatile ConstraintLayout cl;
    ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT,
            ConstraintLayout.LayoutParams.WRAP_CONTENT);
    volatile TextView[] texts;
    volatile Pair<Double, Double> center;
    volatile ElementHelper[] elementHelpers;

    class AngleHelper {
        double foundAngle(Double centerX, Double centerY, Double pointX, Double pointY) {
            // ищем угол с помощью векторов
            pointX -= centerX;
            pointY -= centerY;
            double helpPointX = 1;
            double helpPointY = 0;
            double distance = Math.sqrt(Math.pow(pointX, 2) + Math.pow(pointY, 2));
            double vextorMultiply = pointX * helpPointX + pointY * helpPointY;
            double cosynus = vextorMultiply / distance;
            if (pointY < 0) return 2 * Math.PI - Math.acos(cosynus);
            else return Math.acos(cosynus);
        }
    }

    AngleHelper ah = new AngleHelper();
    Pair<Double, Double>[] coordinates;
    Pair<Double, Double>[] speed;
    final int squareOfElectric = 3000;
    final int length = 100;
    final double springKoef = 1;
    final double frictionKoef = 0.03;
    final double t = 0.01;
    private void visualize(final Link link) {
        for (int i = 0; i < isos.get(n).atomsInLink.size(); i++) {
            for (int j = 0; j < isos.get(n).atomsInLink.get(i).second.length; j++) {
                elementHelpers[i].getLinkAtoms()[j] = elementHelpers[isos.get(n).atomsInLink.get(i).second[j]];
                elementHelpers[i].getImgs()[j].getImage().setImageDrawable(null);
                elementHelpers[i].getImgs()[j].getImage().setVisibility(View.GONE);
                elementHelpers[i].getImgs()[j] = null;
            }
        }
        System.gc();
        for (int i = 0; i < elementHelpers.length; i++) {
            for (int j = 0; j < elementHelpers[i].getLinkAtoms().length; j++) {
                if (elementHelpers[i].getImgs()[j] != null) continue;
                ImageView imageView = new ImageView(DisplayerActivity.this);
                int ll = isos.get(n).atomsInLink.get(i).second[j];
                double distance = Math.sqrt(Math.pow(coordinates[i].first - coordinates[ll].first, 2) +
                        Math.pow(coordinates[i].second - coordinates[ll].second, 2));
                Bitmap b = Bitmap.createBitmap((int) distance + 1, 5, Bitmap.Config.ALPHA_8);
                Canvas c = new Canvas(b);
                c.drawColor(Color.BLACK);
                imageView.setImageBitmap(b);
                imageView.setPivotY(0);
                imageView.setPivotX(0);
                imageView.setAdjustViewBounds(true);
                cl.addView(imageView);
                imageView.setX((float) (coordinates[i].first + texts[i].getPivotX()));
                imageView.setY((float) (coordinates[i].second + texts[i].getPivotY()));
                double angle = ah.foundAngle(
                        coordinates[i].first + texts[i].getPivotX(),
                        coordinates[i].second + texts[i].getPivotY(),
                        coordinates[ll].first + texts[ll].getPivotX(),
                        coordinates[ll].second + texts[ll].getPivotY());
                imageView.setRotation((float) (angle / Math.PI * 180));
                ImageHelper imageHelper = new ImageHelper(imageView, elementHelpers[i], elementHelpers[ll]);
                elementHelpers[i].getImgs()[j] = imageHelper;
                for (int z = 0; z < elementHelpers[ll].getImgs().length; z++) {
                    if (elementHelpers[ll].getImgs()[z] != null) continue;
                    if (isos.get(n).atomsInLink.get(ll).second[z] != i) continue;
                    elementHelpers[ll].getImgs()[z] = imageHelper;
                    break;
                }
            }
        }
        final Animation an = new TranslateAnimation(0, 0, 0, 0);
        Animation.AnimationListener al = new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                for (int i = 0; i < coordinates.length; i++) {
                    Pair<Double, Double> a = new Pair<>(0d, 0d);
                    // kulon's power
                    for (int j = 0; j < coordinates.length; j++) {
                        if (j == i) continue;
                        double distance = Math.sqrt(Math.pow(coordinates[i].first - coordinates[j].first, 2) + Math.pow(coordinates[i].second - coordinates[j].second, 2));
                        double angle = ah.foundAngle(coordinates[j].first, coordinates[j].second, coordinates[i].first, coordinates[i].second);
                        double force = squareOfElectric / distance * Math.sqrt(link.atomsInLink.get(j).first.getVolentnost()) / 2;
                        a = new Pair<>(a.first + force * Math.cos(angle), a.second + force * Math.sin(angle));
                    }
                    for (int l = 0; l < link.atomsInLink.get(i).second.length; l++) {
                        int j = link.atomsInLink.get(i).second[l];
                        double distance = Math.sqrt(Math.pow(coordinates[i].first - coordinates[j].first, 2) + Math.pow(coordinates[i].second - coordinates[j].second, 2));
                        double ang = ah.foundAngle(coordinates[i].first, coordinates[i].second, coordinates[j].first, coordinates[j].second);
                        double force = springKoef * (distance - length) * Math.sqrt(link.atomsInLink.get(j).first.getVolentnost()) / 2;
                        a = new Pair<>(a.first + force * Math.cos(ang), a.second + force * Math.sin(ang));
                    }

                    double distance = Math.sqrt(Math.pow(coordinates[i].first - center.first, 2) + Math.pow(coordinates[i].second - center.second, 2));
                    double ang = ah.foundAngle(coordinates[i].first, coordinates[i].second, center.first, center.second);
                    double force = springKoef / 5 * (distance);
                    a = new Pair<>(a.first + force * Math.cos(ang), a.second + force * Math.sin(ang));
                    speed[i] = new Pair<>((speed[i].first + a.first * t) * (1 - frictionKoef), (speed[i].second + a.second * t) * (1 - frictionKoef));
                }
                for (int i = 0; i < coordinates.length; i++) {
                    coordinates[i] = new Pair<>(coordinates[i].first + speed[i].first * t, coordinates[i].second + speed[i].second);
                    texts[i].setX((float) (double) coordinates[i].first);
                    texts[i].setY((float) (double) coordinates[i].second);
                }

                for (int i = 0; i < elementHelpers.length; i++) {
                    for (int j = 0; j < elementHelpers[i].getImgs().length; j++) {
                        if (elementHelpers[i] != elementHelpers[i].getImgs()[j].getStart())
                            continue;
                        int count = 0;
                        for (int u = 0; u <= j; u++) {
                            if (isos.get(n).atomsInLink.get(i).second[u].equals(isos.get(n).atomsInLink.get(i).second[j]))
                                count++;
                        }


                        int ll = isos.get(n).atomsInLink.get(i).second[j];
                        double distance = Math.sqrt(Math.pow(coordinates[i].first - coordinates[ll].first, 2) +
                                Math.pow(coordinates[i].second - coordinates[ll].second, 2));
                        elementHelpers[i].getImgs()[j].getImage().setAdjustViewBounds(true);
                        Bitmap b = Bitmap.createBitmap((int) distance + 1, 5, Bitmap.Config.ALPHA_8);

                        Canvas c = new Canvas(b);
                        c.drawColor(Color.BLACK);

                        elementHelpers[i].getImgs()[j].getImage().setImageBitmap(b);
                        double angle = ah.foundAngle(
                                coordinates[i].first + texts[i].getPivotX(),
                                coordinates[i].second + texts[i].getPivotY(),
                                coordinates[ll].first + texts[ll].getPivotX(),
                                coordinates[ll].second + texts[ll].getPivotY());

                        double dx = 4 * (count) * Math.pow(-1, count + 1);
                        if (angle < Math.PI / 4 || Math.abs(angle) > Math.PI / 4 * 3 && angle < Math.PI * 5 / 4 || angle > Math.PI * 7 / 4) {
                            elementHelpers[i].getImgs()[j].getImage().setX((float) (coordinates[i].first + texts[i].getPivotX() - 1 * Math.tan(angle) * dx));
                            elementHelpers[i].getImgs()[j].getImage().setY((float) (coordinates[i].second + texts[i].getPivotY() + dx));
                        } else {
                            elementHelpers[i].getImgs()[j].getImage().setX((float) (coordinates[i].first + texts[i].getPivotX() + dx));
                            elementHelpers[i].getImgs()[j].getImage().setY((float) (coordinates[i].second + texts[i].getPivotY() - 1 / Math.tan(angle) * dx));
                        }
                        elementHelpers[i].getImgs()[j].getImage().setRotation((float) (angle / Math.PI * 180));
                    }
                }

                number.startAnimation(animation);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        };
        an.setAnimationListener(al);
        number.startAnimation(an);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displayer);
        // isomer = findViewById(R.id.isomer);
        cl = findViewById(R.id.drawer);
        cl.measure(0, 0);
        isos = ElementChooseActivity.isomers;
        texts = new TextView[isos.get(n).atomsInLink.size()];
        elementHelpers = new ElementHelper[isos.get(n).atomsInLink.size()];
        // isomerView = findViewById(R.id.isomerView);
        // isomer.setText(isos.get(n).toString());
        redraw = findViewById(R.id.reDraw);
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (cl.getMeasuredHeight() == 0) {

                }
                center = new Pair<>(cl.getMeasuredWidth() / 2d, cl.getMeasuredHeight() / 2d);
                for (TextView textView : texts) {
                    textView.measure(0, 0);
                    textView.setPivotX(textView.getMeasuredWidth() >> 1);
                    textView.setPivotY(textView.getMeasuredHeight() >> 1);
                }
            }
        });
        thread.start();
        next = findViewById(R.id.next);
        prtvious = findViewById(R.id.previous);
        number = findViewById(R.id.number);
        number.setText(((n + 1) + " / " + isos.size()));


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n++;
                if (n >= isos.size())
                    n = 0;
                //  isomer.setText(isos.get(n).toString());
                visualize(isos.get(n));
                number.setText(((n + 1) + " / " + isos.size()));
                if (ElementChooseActivity.workThread.isAlive()) {
                    Toast.makeText(DisplayerActivity.this, "Ще не всі ізомери згенеровані.\n Зберігайте спокій і зачекайте", Toast.LENGTH_SHORT).show();
                }
            }
        });
        prtvious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n--;
                if (n < 0) {
                    n = isos.size() - 1;
                }
                //   isomer.setText(isos.get(n).toString());
                visualize(isos.get(n));
                number.setText(((n + 1) + " / " + isos.size()));
                if (ElementChooseActivity.workThread.isAlive()) {
                    Toast.makeText(DisplayerActivity.this, "Ще не всі ізомери згенеровані.\n Зберігайте спокій і зачекайте", Toast.LENGTH_SHORT).show();
                }
            }
        });
        redraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < isos.get(n).atomsInLink.size(); i++) {
                    coordinates[i] = new Pair<>(Math.random() * cl.getMeasuredWidth(), Math.random() * cl.getMeasuredHeight());
                }
            }
        });
        f();
        visualize(isos.get(n));
    }

    void f() {
        coordinates = new Pair[isos.get(0).atomsInLink.size()];
        speed = new Pair[isos.get(0).atomsInLink.size()];
        center = new Pair<>(500d, 800d);
        texts = new TextView[isos.get(n).atomsInLink.size()];
        for (int i = 0; i < isos.get(n).atomsInLink.size(); i++) {
            TextView textView = new TextView(DisplayerActivity.this);
            textView.setTextSize(30);
            textView.setText(isos.get(n).atomsInLink.get(i).first.shortName());
            textView.setX((float) (double) (Math.random() * 1000));
            textView.setY((float) (double) Math.random() * 1600);
            cl.addView(textView, lp);
            texts[i] = textView;
            coordinates[i] = new Pair<>( (double)textView.getX(), (double)textView.getY());
            speed[i] = new Pair<>(0d,0d);
            if (isos.get(n).atomsInLink.get(i).first.equals(Elements.Carbon)) {
                textView.setTextColor(Color.RED);
            }
            if (isos.get(n).atomsInLink.get(i).first.equals(Elements.Oxygen)) {
                textView.setTextColor(Color.BLUE);
            }
            if (isos.get(n).atomsInLink.get(i).first.equals(Elements.Nitrogen)) {
                textView.setTextColor(Color.parseColor("olive"));
            }
            if (isos.get(n).atomsInLink.get(i).first.equals(Elements.Hydrogen)) {
                textView.setTextColor(Color.parseColor("purple"));
            }
            textView.setText(isos.get(n).atomsInLink.get(i).first.shortName());
            elementHelpers[i] = new ElementHelper(isos.get(n).atomsInLink.get(i).first, textView);
        }
        for (int i = 0; i < isos.get(n).atomsInLink.size(); i++) {
            for (int j = 0; j < isos.get(n).atomsInLink.get(i).second.length; j++) {
                elementHelpers[i].getLinkAtoms()[j] = elementHelpers[isos.get(n).atomsInLink.get(i).second[j]];
            }
        }
        for (int i = 0; i < elementHelpers.length; i++) {
            for (int j = 0; j < elementHelpers[i].getLinkAtoms().length; j++) {
                if (elementHelpers[i].getImgs()[j] != null) continue;
                ImageView imageView = new ImageView(DisplayerActivity.this);
                double distance = Math.sqrt(Math.pow(elementHelpers[i].getTextView().getX() - elementHelpers[i].getLinkAtoms()[j].getTextView().getX(), 2) +
                        Math.pow(elementHelpers[i].getTextView().getY() - elementHelpers[i].getLinkAtoms()[j].getTextView().getY(), 2));
                Bitmap b = Bitmap.createBitmap((int) distance + 1, 2, Bitmap.Config.ALPHA_8);
                Canvas c = new Canvas(b);
                c.drawColor(Color.BLACK);
                imageView.setImageBitmap(b);

                cl.addView(imageView, lp);
                imageView.setX(elementHelpers[i].getTextView().getX() + elementHelpers[i].getTextView().getPivotX());
                imageView.setY(elementHelpers[i].getTextView().getY() + elementHelpers[i].getTextView().getPivotY());
                double angle = ah.foundAngle((double) elementHelpers[i].getTextView().getX() + elementHelpers[i].getTextView().getPivotX(),
                        (double) elementHelpers[i].getTextView().getY() + elementHelpers[i].getTextView().getPivotY(),
                        (double) elementHelpers[i].getLinkAtoms()[j].getTextView().getX() + elementHelpers[i].getLinkAtoms()[j].getTextView().getPivotX(),
                        (double) elementHelpers[i].getLinkAtoms()[j].getTextView().getY() + elementHelpers[i].getLinkAtoms()[j].getTextView().getPivotY());
                imageView.setRotation((float) (angle / Math.PI * 180));
                imageView.setAdjustViewBounds(true);
                ImageHelper imageHelper = new ImageHelper(imageView, elementHelpers[i], elementHelpers[i].getLinkAtoms()[j]);

                for (int z = 0; z < elementHelpers[i].getImgs().length; z++) {
                    if (elementHelpers[i].getImgs()[z] != null) continue;
                    elementHelpers[i].getImgs()[z] = imageHelper;
                    break;
                }
                for (int z = 0; z < elementHelpers[i].getLinkAtoms()[j].getImgs().length; z++) {
                    if (elementHelpers[i].getLinkAtoms()[j].getImgs()[z] != null) continue;
                    elementHelpers[i].getLinkAtoms()[j].getImgs()[z] = imageHelper;
                    break;
                }
            }
        }
    }
}
