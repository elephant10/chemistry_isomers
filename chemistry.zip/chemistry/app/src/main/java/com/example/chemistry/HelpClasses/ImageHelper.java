package com.example.chemistry.HelpClasses;

import android.widget.ImageView;

public class ImageHelper {
    private ImageView image;
    private ElementHelper start;
    private ElementHelper finish;

    public ImageHelper(ImageView image, ElementHelper start, ElementHelper finish) {
        this.image = image;
        this.start = start;
        this.finish = finish;
    }


    public ElementHelper getStart() {
        return start;
    }

    public ElementHelper getFinish() {
        return finish;
    }

    public ImageView getImage() {
        return image;
    }
}