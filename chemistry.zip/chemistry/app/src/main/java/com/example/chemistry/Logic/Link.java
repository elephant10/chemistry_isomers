package com.example.chemistry.Logic;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Pair;

import com.example.chemistry.HelpClasses.ToMuchLinksException;
import com.example.chemistry.multiset.Multiset;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class Link implements Cloneable {

    public ArrayList<Pair<Elements, Integer[]>> atomsInLink = new ArrayList<>();

    public Link() {

    }

    Link(Elements element) {
        //Pair<Element, Integer> a = new Pair<>((Element) new Carbon(), 3);
        atomsInLink.add(new Pair<>(element, new Integer[element.getVolentnost()]));
    }

    void setFreeEl(int home, int visitor) {
        for (int i = 0; i < atomsInLink.get(home).second.length; i++) {
            if (atomsInLink.get(home).second[i] == null) {
                atomsInLink.get(home).second[i] = visitor;
                return;
            }
        }
        //  System.out.println(link.get(home).first.getVolentnost());
    }

    void setFreeEl(int home, int visitor, int reqVol) {
        int a = 0;
        for (int i = 0; i < atomsInLink.get(home).second.length; i++) {
            if (atomsInLink.get(home).second[i] == null) {
                atomsInLink.get(home).second[i] = visitor;
                a++;
                if (a == reqVol) return;
            }

        }
    }

    boolean hasFreeEl(int el) {
        for (int i = 0; i < atomsInLink.get(el).second.length; i++)

            if (atomsInLink.get(el).second[i] == null) return true;

        return false;
    }

    int freeEls(int atom) {
        int countOfFree = 0;
        for (int i = 0; i < atomsInLink.get(atom).second.length; i++) {
            if (atomsInLink.get(atom).second[i] == null)
                countOfFree++;
        }
        return countOfFree;
    }


    int add(Elements element, int numberOfConnect) throws ToMuchLinksException {

        int destination = atomsInLink.size() - 1;
        atomsInLink.add(new Pair<>(element, new Integer[element.getVolentnost()]));
        for (int j = destination; j > -1; j--) {
            int a = Integer.min(numberOfConnect, Integer.min(freeEls(j), freeEls(atomsInLink.size() - 1)));
            if (a > 0) {
                setFreeEl(j, atomsInLink.size() - 1, a);
                setFreeEl(atomsInLink.size() - 1, j, a);
            }
            numberOfConnect -= a;
            if (numberOfConnect == 0) return 0;
        }
        return numberOfConnect;
    }

    public HashSet<Integer> findCicclers() {
        final HashSet<Integer> ciclers = new HashSet<>();
        final boolean[] checked = new boolean[atomsInLink.size()];
        final Integer[] prevVert = new Integer[atomsInLink.size()];
        class Helper {
            void recurce(Integer vert) {
                checked[vert] = true;
                HashSet<Integer> ll = new HashSet(Arrays.asList(atomsInLink.get(vert).second));
                for (Integer a : ll) {
                    if (checked[a]) {
                        if (!prevVert[vert].equals(a) && (!ciclers.contains(vert) || !ciclers.contains(a))) {
                            for (int y = vert; y != a; ) {
                                ciclers.add(y);
                                y = prevVert[y];
                            }
                            ciclers.add(a);
                        }
                    } else {
                        prevVert[a] = vert;
                        recurce(a);
                    }
                }
            }
        }
        prevVert[0] = 0;
        new Helper().recurce(0);
        return ciclers;
    }

    void add(Elements element) {
        atomsInLink.add(new Pair<>(element, new Integer[element.getVolentnost()]));
        for (int i = 0; i < atomsInLink.size(); i++) {
            if (hasFreeEl(i)) {
                setFreeEl(i, atomsInLink.size() - 1);
                setFreeEl(atomsInLink.size() - 1, i);
                break;
            }

        }
    }

    void swap(int index1, int item1, int index2, int item2) throws ToMuchLinksException {
        int index3 = atomsInLink.get(index1).second[item1];
        int index4 = atomsInLink.get(index2).second[item2];
        if (index1 == index2 || index3 == index4)
            throw new ToMuchLinksException();
        int item3 = 0;
        int item4 = 0;
        for (int i = 0; i < atomsInLink.get(index3).second.length; i++) {
            if (atomsInLink.get(index3).second[i] == index1) {
                item3 = i;
                break;
            }
        }
        for (int i = 0; i < atomsInLink.get(index4).second.length; i++) {
            if (atomsInLink.get(index4).second[i] == index2) {
                item4 = i;
                break;
            }
        }
        atomsInLink.get(index1).second[item1] = index2;
        atomsInLink.get(index2).second[item2] = index1;
        atomsInLink.get(index3).second[item3] = index4;
        atomsInLink.get(index4).second[item4] = index3;
    }

    public String toString() {
        String s = "";
        for (Pair<Elements, Integer[]> a : atomsInLink
        ) {
            s += atomsInLink.indexOf(a) + " " + a.first.toString() + " " + Arrays.toString(a.second) + "\n";
        }
        //   s += "\n " + longestWay() + " \n";
        return s;
    }

    public LinkName getLinkName() {
        Multiset<Elements> content = new Multiset<>();
        LinkName l = new LinkName(content);
        for (Pair<Elements, Integer[]> a : atomsInLink) {
            content.add(a.first);
        }
        return l;
    }

    @Override
    public boolean equals(Object lin) {
        final Link compareLink = (Link) lin;

        if (this.atomsInLink.size() != compareLink.atomsInLink.size()) return false;

        for (int i = 0; i < compareLink.atomsInLink.size(); i++) {
            if (!compareLink.atomsInLink.get(i).first.equals(atomsInLink.get(0).first)) {
                continue;
            }
            boolean[] checkThis = new boolean[atomsInLink.size()];
            boolean[] checkCompare = new boolean[compareLink.atomsInLink.size()];
            class Helper {
                boolean[] helpArr1;
                boolean[] helpArr2;

                boolean recurce(int indexThis, int indexCompare, boolean[] thiS, boolean[] compare) {
                    if (!atomsInLink.get(indexThis).first.equals(compareLink.atomsInLink.get(indexCompare).first)) {
                        return false;
                    }
                    boolean[] checkedThis = thiS.clone();
                    boolean[] checkedCompare = compare.clone();
                    checkedThis[indexThis] = true;
                    checkedCompare[indexCompare] = true;
                    int checkNum1 = 0;
                    int checkNum2 = 0;
                    for (int i = 0; i < atomsInLink.get(indexThis).second.length; i++) {
                        if (checkedThis[atomsInLink.get(indexThis).second[i]]) checkNum1++;
                    }
                    for (int i = 0; i < compareLink.atomsInLink.get(indexCompare).second.length; i++) {
                        if (checkedCompare[compareLink.atomsInLink.get(indexCompare).second[i]])
                            checkNum2++;
                    }
                    if (checkNum1 != checkNum2) return false;

                    Multiset<Integer> linksOfThis = new Multiset<>();
                    linksOfThis.addAll(Arrays.asList(atomsInLink.get(indexThis).second));

                    Multiset<Integer> linksOfCompare = new Multiset<>();
                    linksOfCompare.addAll(Arrays.asList(compareLink.atomsInLink.get(indexCompare).second));

                    //    if (linksOfThis.elementSet().size() != linksOfCompare.elementSet().size()) return false;
                /*
                Multiset<Integer> linkOfThisClone = linksOfThis.clone();
                Multiset<Integer> linkCompareClone = linksOfCompare.clone();
                pool:
                for (Integer thi : linkOfThisClone.elementSet()) {
                    for (Integer com : linkCompareClone.elementSet()) {
                        if (linkOfThisClone.count(thi) == linkCompareClone.count(com)) {
                            linkCompareClone.setCount(com, 0);
                            continue pool;
                        }
                    }
                }
                if (linkCompareClone.size() != 0) return false;

*/
                    loop:
                    for (int j = 0; j < atomsInLink.get(indexThis).second.length; j++) {
                        for (int l = 0; l < compareLink.atomsInLink.get(indexCompare).second.length; l++) {

                            if (checkedThis[atomsInLink.get(indexThis).second[j]]) {
                                continue loop;
                            }
                            if (checkedCompare[compareLink.atomsInLink.get(indexCompare).second[l]]) {
                                continue;
                            }
                           /* if (thisNumbs[j] != compNumbs[l]) {
                                continue;
                            }*/
                            if (linksOfThis.count(atomsInLink.get(indexThis).second[j]) != linksOfCompare.count(compareLink.atomsInLink.get(indexCompare).second[l])) {
                                continue;
                            }
                            if (recurce(atomsInLink.get(indexThis).second[j], compareLink.atomsInLink.get(indexCompare).second[l], checkedThis, checkedCompare)) {
                                checkedThis = helpArr1;
                                checkedCompare = helpArr2;
                                // System.out.println(Arrays.toString(thiS));
                                /*checkedThis[atomsInLink.get(indexThis).second[j]] = true;
                                checkedCompare[compareLink.atomsInLink.get(indexCompare).second[l]] = true;*/
                                continue loop;
                            }

                            /*checkedThis[atomsInLink.get(indexThis).second[j]] = false;
                            checkedCompare[compareLink.atomsInLink.get(indexCompare).second[l]] = false;*/
                        }
                        checkedCompare[indexCompare] = false;
                        checkedThis[indexThis] = false;
                        return false;
                    }
                    // System.out.println(Arrays.toString(thiS));
                    helpArr1 = checkedThis;
                    // System.out.println(Arrays.toString(thiS));
                    helpArr2 = checkedCompare;
                    return true;
                }
            }
            if (new Helper().recurce(0, i, checkThis, checkCompare)) return true;
        }
        return false;
    }

    public boolean isUnited() {
        final boolean[] checked = new boolean[atomsInLink.size()];
        class Helper {
            void recurse(int index) {
                checked[index] = true;
                for (int i : atomsInLink.get(index).second) {
                    if (!checked[i]) {
                        recurse(i);
                    }
                }
            }
        }
        new Helper().recurse(0);
        for (boolean b : checked) {
            if (!b) return false;
        }
        return true;
    }

    @Override
    protected Link clone() {
        Link a = null;
        try {
            a = (Link) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        a.atomsInLink = (ArrayList<Pair<Elements, Integer[]>>) this.atomsInLink.clone();
        for (int i = 0; i < a.atomsInLink.size(); i++) {
            a.atomsInLink.set(i, new Pair<>(atomsInLink.get(i).first, atomsInLink.get(i).second.clone()));
        }
        return a;
    }

}